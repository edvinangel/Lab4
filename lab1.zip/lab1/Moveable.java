public interface Moveable {
    void move();
    void turnLeft();
    void turnRight();
}
